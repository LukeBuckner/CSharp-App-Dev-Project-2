﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LukeBucknerProject2.Models
{
    /// <summary>
    /// DictionaryEntry class to store elements to compare a submitted word with the dictionary elements
    /// </summary>
    public class DictionaryEntry
    {
        /// <summary>
        /// Gets or sets the letter.
        /// </summary>
        /// <value>
        /// The letter.
        /// </value>
        public char Letter { get; set; }

        /// <summary>
        /// Gets or sets the words.
        /// </summary>
        /// <value>
        /// The words.
        /// </value>
        public List<string> Words { get; set; } = new List<string>();

    }
}
