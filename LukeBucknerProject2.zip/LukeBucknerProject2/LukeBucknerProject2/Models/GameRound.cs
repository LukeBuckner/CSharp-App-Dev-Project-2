﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LukeBucknerProject2.Models
{
    /// <summary>
    /// GameRound class for storing and initializing elements of each round of the game
    /// </summary>
    public class GameRound
    {
        /// <summary>
        /// Gets or sets the word attempts.
        /// </summary>
        /// <value>
        /// The word attempts.
        /// </value>
        public List<WordAttempt> WordAttempts { get; set; } = new List<WordAttempt>();

        /// <summary>
        /// Gets or sets the letters.
        /// </summary>
        /// <value>
        /// The letters.
        /// </value>
        public string Letters { get; set; }

        /// <summary>
        /// Gets or sets the total score.
        /// </summary>
        /// <value>
        /// The total score.
        /// </value>
        public int TotalScore { get; set; }

        /// <summary>
        /// Gets or sets the duration of the timer.
        /// </summary>
        /// <value>
        /// The duration of the timer.
        /// </value>
        public int TimerDuration { get; set; }

        /// <summary>
        /// Gets or sets the date of the game.
        /// </summary>
        /// <value>
        /// The game date.
        /// </value>
        public DateTime GameDate { get; set; }


    }
}
