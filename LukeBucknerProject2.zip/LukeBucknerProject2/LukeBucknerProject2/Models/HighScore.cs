﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LukeBucknerProject2.Models
{
    /// <summary>
    /// HighScore class to initialize and get/set elements for the High Score list
    /// </summary>
    public class HighScore
    {
        /// <summary>
        /// Gets or sets the name of the player.
        /// </summary>
        /// <value>
        /// The name of the player.
        /// </value>
        public string PlayerName { get; set; }

        /// <summary>
        /// Gets or sets the score.
        /// </summary>
        /// <value>
        /// The score.
        /// </value>
        public int Score { get; set; }

        /// <summary>
        /// Gets or sets the duration of the game.
        /// </summary>
        /// <value>
        /// The duration of the game.
        /// </value>
        public int GameDuration { get; set; }

        /// <summary>
        /// Gets or sets the game date.
        /// </summary>
        /// <value>
        /// The game date.
        /// </value>
        public DateTime GameDate { get; set; }
    }
}
