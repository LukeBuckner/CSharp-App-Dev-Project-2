﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LukeBucknerProject2.Models
{
    /// <summary>
    /// WordAttempt class for keepting track of elements tied to each submitted word by the player
    /// </summary>
    public class WordAttempt
    {
        /// <summary>
        /// Gets or sets the word.
        /// </summary>
        /// <value>
        /// The word.
        /// </value>
        public string Word { get; set; }

        /// <summary>
        /// Returns true if the submitted is valid.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is valid; otherwise, <c>false</c>.
        /// </value>
        public bool IsValid { get; set; }

        /// <summary>
        /// Gets or sets the points for each word.
        /// </summary>
        /// <value>
        /// The points.
        /// </value>
        public int Points { get; set; }

        /// <summary>
        /// Gets or sets the time remaining for the game.
        /// </summary>
        /// <value>
        /// The game time remaining.
        /// </value>
        public int GameTimeRemaining { get; set; }

        /// <summary>
        /// Gets or sets the reason a submitted word is marked as invalid.
        /// </summary>
        /// <value>
        /// The invalid reason.
        /// </value>
        public string InvalidReason { get; set; }
    }
}
