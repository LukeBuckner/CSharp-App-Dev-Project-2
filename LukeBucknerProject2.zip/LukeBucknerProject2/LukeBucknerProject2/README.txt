﻿This file is mainly for me to log the functionality of the project and leave details as I go through. I did not finish the extra credit option
and removed it from my final submission. Please see the below notes as needed for clarification on functionalities and known issues.


Implemented all steps of the project. Here are some notes:

- Created a Models namespace to house multiple classes that I made. There are classes for DictionaryEntry, GameRound, HighScore, and WordAttempt

- From the other assignments we did in this class, I decided to implement an option for a user to choose a JSON file for the dictionary. I probably
  could have implemented this just as an imported file in the project to be used, but last time I tried that, it caused a moountain of issues. I tested 
  only with the provided dictionary.json file from Moodle, and it works perfectly as expected.

- Once you load a dictionary, you can start a game by hitting the new game button. You can customize your timer options with the drop down menu or
  by using the shortcut keys (CTRL + 1, 2 or 3 for each respective minute). The default option is always one minute.

- I left some of the games that my wife and I played in the high score board. They can be cleared out and replaced with your data as needed, but
  I left them there for now as they are a great way of showing the sort options working as expected without you having to play multiple games.

- When you finish a round, you will be prompted to enter your name to add to the board if your score makes it into the top 10 high scores. 
  The first 10 will be automatically added there since there is nothing else in the list.
  
- After that when the round is over, you can hit the export button to export the data to a file type of your choice. I misread the instructions
  and thought we had to implement ALL of the options there, so I did that. You can export to JSON, CSV, or txt. All work and showcase the 
  words submitted, including valid and invalid (which will also show the reason they were not accepted).


  Known issues:

  - I left a comment in one of my git commits about this, but I am having some major issues with Resharper right now. It will load up and go through
  the license verification, but after that, it will not appear at all and is not showing any warnings. I was able to get it to show for a short amount
  of time at one point, and I fixed a few warnings at that time, but I have not been able to get it working again since. I went through and did my best
  to catch anything it may have flagged, but I am sure there are probably several that I may have missed, considering how many lines of code I wrote for
  this project.