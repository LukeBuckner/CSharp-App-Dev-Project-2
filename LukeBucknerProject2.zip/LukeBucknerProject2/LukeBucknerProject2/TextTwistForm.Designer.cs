﻿namespace LukeBucknerProject2
{
    partial class TextTwistForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnSubmit = new Button();
            LblLetters = new Label();
            LblTimer = new Label();
            LblScore = new Label();
            LblDictionaryStatus = new Label();
            BtnTwist = new Button();
            BtnNewGame = new Button();
            BtnHighSores = new Button();
            BtnExport = new Button();
            BtnChooseDictionary = new Button();
            menuStrip1 = new MenuStrip();
            menuToolStripMenuItem = new ToolStripMenuItem();
            MenuStripOneMinTimer = new ToolStripMenuItem();
            StripMenuTwoMinTimer = new ToolStripMenuItem();
            MenuStripThreeMinTimer = new ToolStripMenuItem();
            TxtWordInput = new TextBox();
            label1 = new Label();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // BtnSubmit
            // 
            BtnSubmit.Location = new Point(382, 234);
            BtnSubmit.Name = "BtnSubmit";
            BtnSubmit.Size = new Size(75, 23);
            BtnSubmit.TabIndex = 0;
            BtnSubmit.Text = "Submit";
            BtnSubmit.UseVisualStyleBackColor = true;
            BtnSubmit.Click += BtnSubmitWord_Click;
            // 
            // LblLetters
            // 
            LblLetters.AutoSize = true;
            LblLetters.Enabled = false;
            LblLetters.Location = new Point(337, 141);
            LblLetters.Name = "LblLetters";
            LblLetters.Size = new Size(78, 15);
            LblLetters.TabIndex = 1;
            LblLetters.Text = "Letters to Use";
            // 
            // LblTimer
            // 
            LblTimer.AutoSize = true;
            LblTimer.Location = new Point(188, 44);
            LblTimer.Name = "LblTimer";
            LblTimer.Size = new Size(37, 15);
            LblTimer.TabIndex = 2;
            LblTimer.Text = "Timer";
            // 
            // LblScore
            // 
            LblScore.AutoSize = true;
            LblScore.Location = new Point(189, 96);
            LblScore.Name = "LblScore";
            LblScore.Size = new Size(36, 15);
            LblScore.TabIndex = 3;
            LblScore.Text = "Score";
            // 
            // LblDictionaryStatus
            // 
            LblDictionaryStatus.AutoSize = true;
            LblDictionaryStatus.Location = new Point(188, 406);
            LblDictionaryStatus.Name = "LblDictionaryStatus";
            LblDictionaryStatus.Size = new Size(118, 15);
            LblDictionaryStatus.TabIndex = 4;
            LblDictionaryStatus.Text = "No dictionary loaded";
            LblDictionaryStatus.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // BtnTwist
            // 
            BtnTwist.Location = new Point(430, 137);
            BtnTwist.Name = "BtnTwist";
            BtnTwist.Size = new Size(85, 23);
            BtnTwist.TabIndex = 5;
            BtnTwist.Text = "Twist Letters";
            BtnTwist.UseVisualStyleBackColor = true;
            BtnTwist.Click += BtnTwistLetters_Click;
            // 
            // BtnNewGame
            // 
            BtnNewGame.Location = new Point(382, 359);
            BtnNewGame.Name = "BtnNewGame";
            BtnNewGame.Size = new Size(75, 23);
            BtnNewGame.TabIndex = 6;
            BtnNewGame.Text = "New Game";
            BtnNewGame.UseVisualStyleBackColor = true;
            BtnNewGame.Click += BtnStartGame_Click;
            // 
            // BtnHighSores
            // 
            BtnHighSores.Location = new Point(649, 36);
            BtnHighSores.Name = "BtnHighSores";
            BtnHighSores.Size = new Size(139, 23);
            BtnHighSores.TabIndex = 7;
            BtnHighSores.Text = "View High Scores";
            BtnHighSores.UseVisualStyleBackColor = true;
            BtnHighSores.Click += BtnViewHighScores_Click;
            // 
            // BtnExport
            // 
            BtnExport.Location = new Point(649, 88);
            BtnExport.Name = "BtnExport";
            BtnExport.Size = new Size(139, 23);
            BtnExport.TabIndex = 8;
            BtnExport.Text = "Export Stats";
            BtnExport.UseVisualStyleBackColor = true;
            BtnExport.Click += BtnExportStats_Click;
            // 
            // BtnChooseDictionary
            // 
            BtnChooseDictionary.Location = new Point(43, 402);
            BtnChooseDictionary.Name = "BtnChooseDictionary";
            BtnChooseDictionary.Size = new Size(139, 23);
            BtnChooseDictionary.TabIndex = 9;
            BtnChooseDictionary.Text = "Choose Dictionary";
            BtnChooseDictionary.UseVisualStyleBackColor = true;
            BtnChooseDictionary.Click += BtnChooseDictionary_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { menuToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 10;
            menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            menuToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { MenuStripOneMinTimer, StripMenuTwoMinTimer, MenuStripThreeMinTimer });
            menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            menuToolStripMenuItem.Size = new Size(68, 20);
            menuToolStripMenuItem.Text = "Set Timer";
            // 
            // MenuStripOneMinTimer
            // 
            MenuStripOneMinTimer.Name = "MenuStripOneMinTimer";
            MenuStripOneMinTimer.ShortcutKeys = Keys.Control | Keys.D1;
            MenuStripOneMinTimer.Size = new Size(166, 22);
            MenuStripOneMinTimer.Text = "1 Minute";
            MenuStripOneMinTimer.Click += MenuStripOneMinTimer_Click;
            // 
            // StripMenuTwoMinTimer
            // 
            StripMenuTwoMinTimer.Name = "StripMenuTwoMinTimer";
            StripMenuTwoMinTimer.ShortcutKeys = Keys.Control | Keys.D2;
            StripMenuTwoMinTimer.Size = new Size(166, 22);
            StripMenuTwoMinTimer.Text = "2 Minutes";
            StripMenuTwoMinTimer.Click += MenuStripTwoMinTimer_Click;
            // 
            // MenuStripThreeMinTimer
            // 
            MenuStripThreeMinTimer.Name = "MenuStripThreeMinTimer";
            MenuStripThreeMinTimer.ShortcutKeys = Keys.Control | Keys.D3;
            MenuStripThreeMinTimer.Size = new Size(166, 22);
            MenuStripThreeMinTimer.Text = "3 Minutes";
            MenuStripThreeMinTimer.Click += MenuStripThreeMinTimer_Click;
            // 
            // TxtWordInput
            // 
            TxtWordInput.Location = new Point(337, 205);
            TxtWordInput.Name = "TxtWordInput";
            TxtWordInput.Size = new Size(178, 23);
            TxtWordInput.TabIndex = 11;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(257, 208);
            label1.Name = "label1";
            label1.Size = new Size(74, 15);
            label1.TabIndex = 12;
            label1.Text = "Enter Words:";
            // 
            // TextTwistForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(TxtWordInput);
            Controls.Add(BtnChooseDictionary);
            Controls.Add(BtnExport);
            Controls.Add(BtnHighSores);
            Controls.Add(BtnNewGame);
            Controls.Add(BtnTwist);
            Controls.Add(LblDictionaryStatus);
            Controls.Add(LblScore);
            Controls.Add(LblTimer);
            Controls.Add(LblLetters);
            Controls.Add(BtnSubmit);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "TextTwistForm";
            Text = "Text Twist by Buckner";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BtnSubmit;
        private Label LblLetters;
        private Label LblTimer;
        private Label LblScore;
        private Label LblDictionaryStatus;
        private Button BtnTwist;
        private Button BtnNewGame;
        private Button BtnHighSores;
        private Button BtnExport;
        private Button BtnChooseDictionary;
        private MenuStrip menuStrip1;
        private TextBox TxtWordInput;
        private ToolStripMenuItem menuToolStripMenuItem;
        private ToolStripMenuItem MenuStripOneMinTimer;
        private ToolStripMenuItem StripMenuTwoMinTimer;
        private ToolStripMenuItem MenuStripThreeMinTimer;
        private Label label1;
    }
}
