using LukeBucknerProject2.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;
using Timer = System.Windows.Forms.Timer;

namespace LukeBucknerProject2
{
    /// <summary>
    /// TextTwistForm : Form
    /// </summary>
    /// <seealso cref="System.Windows.Forms.Form" />
    public partial class TextTwistForm : Form
    {
        /// <summary>
        /// random generator for the chosen letters to use each round
        /// </summary>
        private readonly Random random = new Random();

        /// <summary>
        /// The current letters
        /// </summary>
        private List<char> currentLetters = new List<char>();

        /// <summary>
        /// The dictionary file path - player must select a dictionary before playing. I did it
        /// this way because the other assignments we had that used JSON files were best implemented this
        /// way. This way we don't have to store the file locally in the program, which could lead to other problems
        /// </summary>
        private string dictionaryFilePath = null;

        /// <summary>
        /// The game rounds list
        /// </summary>
        private List<GameRound> gameRounds = new List<GameRound>();

        /// <summary>
        /// The current round
        /// </summary>
        private GameRound currentRound;

        /// <summary>
        /// The current score
        /// </summary>
        private int currentScore = 0;

        /// <summary>
        /// The timer duration. Defaults to one minute
        /// </summary>
        private int timerDuration = 60;

        /// <summary>
        /// The game timer
        /// </summary>
        private Timer gameTimer;

        /// <summary>
        /// The remaining time for the round
        /// </summary>
        private int remainingTime;

        /// <summary>
        /// The high scores list
        /// </summary>
        private List<HighScore> highScores = new List<HighScore>();

        /// <summary>
        /// The cached dictionary - the program caches the dictionary after it is selected
        /// to compare submitted words and determine if they are valid or not
        /// </summary>
        private List<DictionaryEntry> cachedDictionary = null;

        /// <summary>
        /// Constant for setting the timer to one minute from menu strip
        /// </summary>
        private const int ONE_MINUTE = 60;

        /// <summary>
        /// Constant for setting timer to two minutes from menu strip
        /// </summary>
        private const int TWO_MINUTES = 120;

        /// <summary>
        /// Constant for setting the timer to three minutes from the menu strip
        /// </summary>
        private const int THREE_MINUTES = 180;

        /// <summary>
        /// Initializes a new instance of the <see cref="TextTwistForm"/> class.
        /// Loads the list of high scores when started. This keeps the list even if the 
        /// game is closed and re-opened
        /// </summary>
        public TextTwistForm()
        {
            InitializeComponent();
            LoadHighScores();
        }

        /// <summary>
        /// Handles the Click event of the BtnChooseDictionary control. Player has to
        /// choose a dictionary before playing. In our case, it will alwyas be the provided
        /// file from Moodle, but I believe this to be best practice in this type of program.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void BtnChooseDictionary_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "JSON Files (*.json)|*.json",
                Title = "Choose Dictionary File"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    dictionaryFilePath = openFileDialog.FileName;
                    cachedDictionary = LoadJsonDictionary();

                    // error handling for further verification

                    if (cachedDictionary.Any())
                    {
                        var sampleLetter = cachedDictionary[0].Letter;
                        var sampleWords = cachedDictionary[0].Words.Take(3);
                        Console.WriteLine($"Successfully loaded dictionary. Sample entry - Letter: {sampleLetter}, First few words: {string.Join(", ", sampleWords)}");

                        LblDictionaryStatus.Text = "Dictionary Loaded Successfully!";
                        LblDictionaryStatus.ForeColor = System.Drawing.Color.Green;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading dictionary: {ex.Message}");
                    dictionaryFilePath = null;
                    cachedDictionary = null;
                    LblDictionaryStatus.Text = "Dictionary Load Failed!";
                    LblDictionaryStatus.ForeColor = System.Drawing.Color.Red;
                }
            }
        }

        /// <summary>
        /// Initializes the game. Throws an error if you don't choose a dictionary before hitting New Game.
        /// </summary>
        private void InitializeGame()
        {
            if (dictionaryFilePath == null)
            {
                MessageBox.Show("Please load a dictionary before starting the game.");
                return;
            }

            // gets random letters for the player to use in the round
            currentLetters = GenerateRandomLetters();
            DisplayLetters();
            remainingTime = timerDuration;
            currentScore = 0;
            LblTimer.Text = $"{remainingTime} seconds";
            LblScore.Text = $"Score: {currentScore}";
        }

        /// <summary>
        /// Displays the letters that the player must use in the round.
        /// </summary>
        private void DisplayLetters()
        {
            LblLetters.Text = string.Join(" ", currentLetters);
        }

        /// <summary>
        /// Generates the random letters for the round, based on the frequencies from the instructions in Moodle.
        /// </summary>
        /// <returns></returns>
        private List<char> GenerateRandomLetters()
        {
            var letters = new List<char>();
            var frequencies = new Dictionary<char, int>
            {
                { 'e', 11 }, { 't', 9 }, { 'o', 8 }, { 'a', 6 }, { 'i', 6 }, { 'n', 6 },
                { 's', 6 }, { 'h', 5 }, { 'r', 5 }, { 'l', 4 }, { 'd', 3 }, { 'u', 3 },
                { 'w', 3 }, { 'y', 3 }, { 'b', 2 }, { 'c', 2 }, { 'f', 2 }, { 'g', 2 },
                { 'm', 2 }, { 'p', 2 }, { 'v', 2 }, { 'j', 1 }, { 'k', 1 }, { 'q', 1 },
                { 'x', 1 }, { 'z', 1 }
            };

            // letters are grabbed from a bag list, suggested in the instructions. I could not find a more efficient way for this
            var bag = frequencies.SelectMany(kv => Enumerable.Repeat(kv.Key, kv.Value)).ToList();

            var tempBag = new List<char>(bag);
            for (int i = 0; i < 7; i++)
            {
                int index = random.Next(tempBag.Count);
                letters.Add(tempBag[index]);
                tempBag.RemoveAt(index);
            }

            return letters;
        }

        /// <summary>
        /// Loads the selected json dictionary.
        /// </summary>
        /// <returns></returns>
        /// <exception cref="System.Exception">
        /// Dictionary file path is not set.
        /// or
        /// Dictionary file is empty or invalid.
        /// or
        /// Failed to parse dictionary: {ex.Message}
        /// </exception>
        private List<DictionaryEntry> LoadJsonDictionary()
        {
            if (string.IsNullOrEmpty(dictionaryFilePath))
            {
                throw new Exception("Dictionary file path is not set.");
            }

            try
            {
                string jsonData = File.ReadAllText(dictionaryFilePath);
                var options = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true,
                    AllowTrailingCommas = true
                };

                var dictionaryEntries = JsonSerializer.Deserialize<List<DictionaryEntry>>(jsonData, options);

                if (dictionaryEntries == null || !dictionaryEntries.Any())
                {
                    throw new Exception("Dictionary file is empty or invalid.");
                }

                // converts all words to lowercase for consistent comparison. I think they are already that way, but just in case
                foreach (var entry in dictionaryEntries)
                {
                    entry.Words = entry.Words.Select(w => w.ToLower().Trim()).ToList();
                }

                return dictionaryEntries;
            }
            // error handling if the program can't go through the selected dictionary
            catch (Exception ex)
            {
                throw new Exception($"Failed to parse dictionary: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Determines whether the submitted word from a player is in the dictionary or not.
        /// </summary>
        /// <param name="word">The word.</param>
        /// <returns>
        ///   <c>true</c> if [is word in dictionary] [the specified word]; otherwise, <c>false</c>.
        /// </returns>
        private bool IsWordInDictionary(string word)
        {
            try
            {
                // more error handling. suggested by Resharper
                if (cachedDictionary == null)
                {
                    MessageBox.Show("Dictionary not loaded properly.");
                    return false;
                }

                word = word.ToLower().Trim();

                // this part verifies if the submitted word can be made from current letters
                var availableLetters = new List<char>(currentLetters);
                foreach (var c in word)
                {
                    if (!availableLetters.Contains(c))
                    {
                        Console.WriteLine($"Word '{word}' contains unavailable letter: {c}");
                        return false;
                    }
                    availableLetters.Remove(c);
                }

                // checks if it exists in dictionary
                char firstLetter = word[0];
                var entry = cachedDictionary.FirstOrDefault(e =>
                    char.ToLower(e.Letter) == char.ToLower(firstLetter));

                if (entry == null)
                {
                    Console.WriteLine($"No dictionary entry found for letter: {firstLetter}");
                    return false;
                }

                bool exists = entry.Words.Contains(word);
                Console.WriteLine($"Word '{word}' {(exists ? "found" : "not found")} in dictionary");
                return exists;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in IsWordInDictionary: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Handles the Click event of the BtnStartGame control. Click New Game to start the game
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void BtnStartGame_Click(object sender, EventArgs e)
        {
            if (dictionaryFilePath == null)
            {
                MessageBox.Show("Please load a dictionary before starting the game.");
                return;
            }

            InitializeGame();
            StartGame();
        }

        /// <summary>
        /// Stops the timer after reaching 0 seconds remaining
        /// </summary>
        private void StopTimer()
        {
            if (gameTimer != null)
            {
                gameTimer.Stop();
                gameTimer.Tick -= GameTimer_Tick;
                gameTimer.Dispose();
                gameTimer = null;
            }
        }

        /// <summary>
        /// Starts the game and begins the timer tick
        /// </summary>
        private void StartGame()
        {
            StopTimer();
            currentRound = new GameRound
            {
                Letters = string.Join("", currentLetters),
                TimerDuration = timerDuration,
                GameDate = DateTime.Now
            };
            gameTimer = new Timer();
            gameTimer.Interval = 1000;
            gameTimer.Tick += GameTimer_Tick;
            remainingTime = timerDuration;
            LblTimer.Text = $"{remainingTime} seconds";
            gameTimer.Start();
        }

        /// <summary>
        /// Handles the ticking of the GameTimer.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void GameTimer_Tick(object sender, EventArgs e)
        {
            if (remainingTime <= 0)
            {
                StopTimer();
                EndGame();
                return;
            }

            remainingTime--;
            LblTimer.Text = $"{remainingTime} seconds";
        }

        /// <summary>
        /// Submits the word after meeting pre-condition and parameter checks
        /// </summary>
        /// <param name="word">The word.</param>
        private void SubmitWord(string word)
        {
            word = word.Trim().ToLower();
            var attempt = new WordAttempt
            {
                Word = word,
                GameTimeRemaining = remainingTime
            };

            // check minimum length
            if (word.Length < 3)
            {
                attempt.IsValid = false;
                attempt.InvalidReason = "Word must be at least 3 letters long";
                currentRound.WordAttempts.Add(attempt);
                MessageBox.Show(attempt.InvalidReason);
                return;
            }

            // see if word was already used
            if (currentRound.WordAttempts.Any(w => w.IsValid && w.Word == word))
            {
                attempt.IsValid = false;
                attempt.InvalidReason = "Word already used";
                currentRound.WordAttempts.Add(attempt);
                MessageBox.Show(attempt.InvalidReason);
                return;
            }

            // check in dictionary
            if (!IsWordInDictionary(word))
            {
                attempt.IsValid = false;
                attempt.InvalidReason = "Word not found in dictionary";
                currentRound.WordAttempts.Add(attempt);
                MessageBox.Show(attempt.InvalidReason);
                return;
            }

            // if word is valid
            attempt.IsValid = true;
            attempt.Points = CalculateWordScore(word);
            currentScore += attempt.Points;
            currentRound.TotalScore = currentScore;
            currentRound.WordAttempts.Add(attempt);

            LblScore.Text = $"Score: {currentScore}";
            MessageBox.Show($"'{word}' accepted! Score: {attempt.Points}");
        }

        /// <summary>
        /// Handles the Click event of the BtnSubmitWord control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void BtnSubmitWord_Click(object sender, EventArgs e)
        {
            string word = TxtWordInput.Text.Trim().ToLower();

            if (string.IsNullOrEmpty(word))
            {
                MessageBox.Show("Please enter a word.");
                return;
            }

            SubmitWord(word);
            TxtWordInput.Clear();
        }

        /// <summary>
        /// Handles the Click event of the BtnTwistLetters control. Randomly rearranges the order of the letters
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void BtnTwistLetters_Click(object sender, EventArgs e)
        {
            currentLetters = currentLetters.OrderBy(_ => random.Next()).ToList();
            DisplayLetters();
        }

        /// <summary>
        /// Checks the and update high scores after each round.
        /// </summary>
        private void CheckAndUpdateHighScores()
        {
            try
            {
                if (currentRound == null) return;

                highScores ??= new List<HighScore>();

                // checks if this score qualifies as a high score to go on the score board
                if (highScores.Count < 10 || currentRound.TotalScore > highScores.Min(h => h.Score))
                {
                    // after the round, this displays a form to get the player's name to put on the score board
                    var nameInput = new Form()
                    {
                        Width = 300,
                        Height = 150,
                        FormBorderStyle = FormBorderStyle.FixedDialog,
                        Text = "New High Score!",
                        StartPosition = FormStartPosition.CenterScreen
                    };

                    var textBox = new TextBox() { Left = 50, Top = 20, Width = 200 };
                    var label = new Label()
                    {
                        Left = 50,
                        Top = 5,
                        Text = $"Congratulations! You scored {currentRound.TotalScore} points!\nEnter your name:"
                    };
                    var buttonOk = new Button()
                    {
                        Text = "OK",
                        Left = 50,
                        Width = 100,
                        Top = 50,
                        DialogResult = DialogResult.OK
                    };
                    var buttonCancel = new Button()
                    {
                        Text = "Cancel",
                        Left = 150,
                        Width = 100,
                        Top = 50,
                        DialogResult = DialogResult.Cancel
                    };

                    nameInput.Controls.AddRange(new Control[] { textBox, label, buttonOk, buttonCancel });
                    nameInput.AcceptButton = buttonOk;
                    nameInput.CancelButton = buttonCancel;

                    string playerName = "Player";
                    if (nameInput.ShowDialog() == DialogResult.OK && !string.IsNullOrWhiteSpace(textBox.Text))
                    {
                        playerName = textBox.Text;
                    }

                    // adds the new high score to the score board
                    highScores.Add(new HighScore
                    {
                        PlayerName = playerName,
                        Score = currentRound.TotalScore,
                        GameDuration = currentRound.TimerDuration,
                        GameDate = currentRound.GameDate
                    });

                    // the board only stores 10 scores. the board can be reset with the button at the top
                    highScores = highScores
                        .OrderByDescending(h => h.Score)
                        .Take(10)
                        .ToList();

                    // save to file. After a round, the player can hit the export button to export that round's score and 
                    // each word (valid and invalid)
                    SaveHighScores();

                    MessageBox.Show($"High score saved! View the high score board to see your ranking.",
                        "Congratulations!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating high scores: {ex.Message}");
            }
        }

        /// <summary>
        /// Ends the game. Provides the player with a summary of the round, only showing valid words and their points.
        /// the player can view invalid words too with an export of the round to their choice of file type - CSV, JSON, or txt
        /// </summary>
        private void EndGame()
        {
            StopTimer();

            // display a summary of the round
            var validWords = currentRound.WordAttempts
                .Where(w => w.IsValid)
                .OrderByDescending(w => w.Points);

            string summary = "Round Complete!\n\nValid Words:\n";
            foreach (var word in validWords)
            {
                summary += $"{word.Word}: {word.Points} points\n";
            }
            summary += $"\nTotal Score: {currentRound.TotalScore}";

            MessageBox.Show(summary);

            // adds round to game history
            gameRounds.Add(currentRound);

            // updates the high scores list
            CheckAndUpdateHighScores();

            // resets for a new game
            InitializeGame();
        }

        /// <summary>
        /// Calculates the word score based off of instructions
        /// </summary>
        /// <param name="word">The word.</param>
        /// <returns></returns>
        private int CalculateWordScore(string word)
        {
            return word.Length switch
            {
                3 => 90,
                4 => 160,
                5 => 250,
                6 => 360,
                7 => 490,
                _ => 0
            };
        }

        /// <summary>
        /// Saves the high scores.
        /// </summary>
        private void SaveHighScores()
        {
            try
            {
                string highScoresPath = Path.Combine(
                    Path.GetDirectoryName(Application.ExecutablePath),
                    "highscores.json"
                );

                string jsonData = JsonSerializer.Serialize(highScores, new JsonSerializerOptions
                {
                    WriteIndented = true
                });

                File.WriteAllText(highScoresPath, jsonData);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving high scores: {ex.Message}");
            }
        }

        /// <summary>
        /// Loads the high scores even if the game is closed and reopened.
        /// </summary>
        private void LoadHighScores()
        {
            try
            {
                string highScoresPath = Path.Combine(
                    Path.GetDirectoryName(Application.ExecutablePath),
                    "highscores.json"
                );

                if (File.Exists(highScoresPath))
                {
                    string jsonData = File.ReadAllText(highScoresPath);
                    highScores = JsonSerializer.Deserialize<List<HighScore>>(jsonData);
                }
                else
                {
                    highScores = new List<HighScore>();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading high scores: {ex.Message}");
                highScores = new List<HighScore>();
            }
        }

        /// <summary>
        /// Handles the Click event of the BtnViewHighScores control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void BtnViewHighScores_Click(object sender, EventArgs e)
        {
            if (highScores == null || !highScores.Any())
            {
                MessageBox.Show("No high scores available yet.", "High Scores", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // I was having issues with other options, so this way will create a form that displays the high scores with the
            // sorting options at the top. 
            var highScoreForm = new Form
            {
                Text = "High Scores",
                Size = new Size(600, 400),
                StartPosition = FormStartPosition.CenterParent,
                MinimizeBox = false,
                MaximizeBox = false,
                FormBorderStyle = FormBorderStyle.FixedDialog
            };

            var listView = new ListView
            {
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                Size = new Size(560, 300),
                Location = new Point(10, 40)
            };

            listView.Columns.Add("Rank", 50);
            listView.Columns.Add("Player", 150);
            listView.Columns.Add("Score", 100);
            listView.Columns.Add("Time", 100);
            listView.Columns.Add("Date", 150);

            var sortByScoreBtn = new Button
            {
                Text = "Sort by Score",
                Location = new Point(10, 10),
                Size = new Size(100, 25)
            };

            // this sorts each time separetely, descendingly based on score
            var sortByTimeAndScoreBtn = new Button
            {
                Text = "Sort by Time/Score",
                Location = new Point(120, 10),
                Size = new Size(120, 25)
            };

            // since the score board only holds up to 10 scores, they can be reset with this option. 
            // Tested and confirmed this is working and updates properly when closing and reopening the game
            var resetBtn = new Button
            {
                Text = "Reset Scores",
                Location = new Point(250, 10),
                Size = new Size(100, 25)
            };

            // sort by score handler
            sortByScoreBtn.Click += (s, ev) =>
            {
                listView.Items.Clear();
                var sorted = highScores.OrderByDescending(hs => hs.Score);
                DisplayHighScores(sorted, listView);
            };

            // sort by time and score handler
            sortByTimeAndScoreBtn.Click += (s, ev) =>
            {
                listView.Items.Clear();
                var sorted = highScores
                    .OrderBy(hs => hs.GameDuration)
                    .ThenByDescending(hs => hs.Score);
                DisplayHighScores(sorted, listView);
            };

            // Reset button handler
            resetBtn.Click += (s, ev) =>
            {
                // confirm before resetting
                if (MessageBox.Show("Are you sure you want to reset all high scores?", "Confirm Reset",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    highScores.Clear();
                    SaveHighScores();
                    listView.Items.Clear();
                    MessageBox.Show("High scores have been reset.", "Reset Complete",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            };

            // the initial display for this form is sorted by score
            DisplayHighScores(highScores.OrderByDescending(hs => hs.Score), listView);

            highScoreForm.Controls.AddRange(new Control[] { listView, sortByScoreBtn, sortByTimeAndScoreBtn, resetBtn });
            highScoreForm.ShowDialog();
        }

        /// <summary>
        /// Displays the high scores.
        /// </summary>
        /// <param name="scores">The scores.</param>
        /// <param name="listView">The list view.</param>
        private void DisplayHighScores(IEnumerable<HighScore> scores, ListView listView)
        {
            int rank = 1;
            foreach (var score in scores)
            {
                var item = new ListViewItem(rank.ToString());
                item.SubItems.Add(score.PlayerName);
                item.SubItems.Add(score.Score.ToString());
                item.SubItems.Add($"{score.GameDuration} seconds");
                item.SubItems.Add(score.GameDate.ToString("MM/dd/yyyy HH:mm"));
                listView.Items.Add(item);
                rank++;
            }
        }

        /// <summary>
        /// Handles the Click event of the BtnExportStats control.
        /// You can export as CSV, JSON, or txt
        /// Confirmed that all of these options work properly. Each displays the time left when a word was submitted
        /// and also shows the list of invalid words and the reasons they were not accepted
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void BtnExportStats_Click(object sender, EventArgs e)
        {
            if (!gameRounds.Any())
            {
                MessageBox.Show("No game statistics available to export. Play some games first!",
                    "Export Stats", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var saveFileDialog = new SaveFileDialog
            {
                Filter = "JSON files (*.json)|*.json|CSV files (*.csv)|*.csv|Text files (*.txt)|*.txt",
                Title = "Export Game Statistics",
                FileName = $"TextTwist_Stats_{DateTime.Now:yyyyMMdd_HHmmss}"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string extension = Path.GetExtension(saveFileDialog.FileName).ToLower();
                    switch (extension)
                    {
                        case ".json":
                            ExportStatsAsJson(saveFileDialog.FileName);
                            break;
                        case ".csv":
                            ExportStatsAsCsv(saveFileDialog.FileName);
                            break;
                        case ".txt":
                            ExportStatsAsTxt(saveFileDialog.FileName);
                            break;
                    }
                    MessageBox.Show("Statistics exported successfully!", "Export Complete",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error exporting statistics: {ex.Message}", "Export Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Exports the stats as json.
        /// </summary>
        /// <param name="filename">The filename.</param>
        private void ExportStatsAsJson(string filename)
        {
            var exportData = new
            {
                ExportDate = DateTime.Now,
                TotalGames = gameRounds.Count,
                TotalScore = gameRounds.Sum(r => r.TotalScore),
                AverageScore = gameRounds.Average(r => r.TotalScore),
                GameRounds = gameRounds.Select(r => new
                {
                    Date = r.GameDate,
                    r.Letters,
                    r.TotalScore,
                    r.TimerDuration,
                    ValidWords = r.WordAttempts.Where(w => w.IsValid)
                        .Select(w => new
                        {
                            w.Word,
                            w.Points,
                            TimeRemaining = w.GameTimeRemaining,
                            TimeElapsed = r.TimerDuration - w.GameTimeRemaining
                        }),
                    InvalidAttempts = r.WordAttempts.Where(w => !w.IsValid)
                        .Select(w => new
                        {
                            w.Word,
                            w.InvalidReason,
                            TimeRemaining = w.GameTimeRemaining,
                            TimeElapsed = r.TimerDuration - w.GameTimeRemaining
                        })
                }).ToList()
            };

            string json = JsonSerializer.Serialize(exportData, new JsonSerializerOptions
            {
                WriteIndented = true,
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });
            File.WriteAllText(filename, json);
        }

        /// <summary>
        /// Exports the stats as CSV.
        /// </summary>
        /// <param name="filename">The filename.</param>
        private void ExportStatsAsCsv(string filename)
        {
            using var writer = new StreamWriter(filename);

            // header
            writer.WriteLine("Game Date,Letters,Total Score,Timer Duration,Word,Valid,Points,Reason,Time Remaining");

            // data
            foreach (var round in gameRounds)
            {
                foreach (var attempt in round.WordAttempts)
                {
                    writer.WriteLine($"{round.GameDate:yyyy-MM-dd HH:mm:ss}," +
                                   $"\"{round.Letters}\"," +
                                   $"{round.TotalScore}," +
                                   $"{round.TimerDuration}," +
                                   $"\"{attempt.Word}\"," +
                                   $"{attempt.IsValid}," +
                                   $"{attempt.Points}," +
                                   $"\"{attempt.InvalidReason ?? ""}\"," +
                                   $"{attempt.GameTimeRemaining}");
                }
            }
        }

        /// <summary>
        /// Exports the stats as text.
        /// </summary>
        /// <param name="filename">The filename.</param>
        private void ExportStatsAsTxt(string filename)
        {
            using var writer = new StreamWriter(filename);

            writer.WriteLine("Text Twist Game Statistics");
            writer.WriteLine($"Export Date: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            writer.WriteLine($"Total Games Played: {gameRounds.Count}");
            writer.WriteLine($"Total Score: {gameRounds.Sum(r => r.TotalScore)}");
            writer.WriteLine($"Average Score: {gameRounds.Average(r => r.TotalScore):F2}");
            writer.WriteLine();

            foreach (var round in gameRounds)
            {
                writer.WriteLine($"Game Round - {round.GameDate:yyyy-MM-dd HH:mm:ss}");
                writer.WriteLine($"Letters: {round.Letters}");
                writer.WriteLine($"Total Score: {round.TotalScore}");
                writer.WriteLine($"Timer Duration: {round.TimerDuration} seconds");
                writer.WriteLine("\nValid Words:");
                foreach (var attempt in round.WordAttempts.Where(w => w.IsValid))
                {
                    writer.WriteLine($"  {attempt.Word,-15} {attempt.Points,5} points  ({attempt.GameTimeRemaining}s remaining)");
                }
                writer.WriteLine("\nInvalid Attempts:");
                foreach (var attempt in round.WordAttempts.Where(w => !w.IsValid))
                {
                    writer.WriteLine($"  {attempt.Word,-15} - {attempt.InvalidReason} ({attempt.GameTimeRemaining}s remaining)");
                }
                writer.WriteLine("\n" + new string('-', 50) + "\n");
            }
        }

        /// <summary>
        /// Updates the timer display. Last minute change to update the timer based
        /// on what you select in the menu bar timer settings
        /// </summary>
        private void UpdateTimerDisplay()
        {
            remainingTime = timerDuration;
            LblTimer.Text = $"{remainingTime} seconds";
        }

        /// <summary>
        /// Handles the Click event of the MenuStripOneMinTimer control.
        /// Sets timer to one minute
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void MenuStripOneMinTimer_Click(object sender, EventArgs e)
        {
            timerDuration = ONE_MINUTE;
            UpdateTimerDisplay();
        }

        /// <summary>
        /// Handles the Click event of the MenuStripTwoMinTimer control.
        /// sets timer to two minutes
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void MenuStripTwoMinTimer_Click(object sender, EventArgs e)
        {
            timerDuration = TWO_MINUTES;
            UpdateTimerDisplay();
        }

        /// <summary>
        /// Handles the Click event of the MenuStripThreeMinTimer control.
        /// sets timer to three minutes
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void MenuStripThreeMinTimer_Click(object sender, EventArgs e)
        {
            timerDuration = THREE_MINUTES;
            UpdateTimerDisplay();
        }
    }
}